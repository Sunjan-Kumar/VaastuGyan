// static/js/compass.js - FIXED VERSION
class VaastuCompass {
    constructor() {
        this.directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
        this.vaastuLabels = {
            'N': 'उत्तर (North) - कुबेर',
            'NE': 'ईशान (North-East)',
            'E': 'पूर्व (East) - इंद्र',
            'SE': 'आग्नेय (South-East) - अग्नि',
            'S': 'दक्षिण (South) - यम',
            'SW': 'नैऋत्य (South-West)',
            'W': 'पश्चिम (West) - वरुण',
            'NW': 'वायव्य (North-West) - वायु'
        };
        this.initialized = false;
        this.orientationHandler = null;
        this.init();
    }

    init() {
        this.createDirectionLabels();
        
        if (window.DeviceOrientationEvent) {
            // Request permission on iOS 13+
            if (typeof DeviceOrientationEvent.requestPermission === 'function') {
                DeviceOrientationEvent.requestPermission()
                    .then(permissionState => {
                        if (permissionState === 'granted') {
                            this.startCompass();
                        } else {
                            this.showNoPermission();
                        }
                    })
                    .catch(console.error);
            } else {
                // Non-iOS devices
                this.startCompass();
            }
        } else {
            document.getElementById('directionText').textContent = 'इस डिवाइस में कम्पास सपोर्ट नहीं';
        }
    }

    startCompass() {
        this.orientationHandler = (e) => this.handleOrientation(e);
        window.addEventListener('deviceorientation', this.orientationHandler);
        document.getElementById('directionText').textContent = 'कम्पास सक्रिय - फोन समतल रखें';
        this.initialized = true;
    }

    showNoPermission() {
        document.getElementById('directionText').textContent = 'कम्पास के लिए permission दें';
    }

    createDirectionLabels() {
        const container = document.getElementById('directionLabels');
        container.innerHTML = ''; // Clear existing labels
        
        this.directions.forEach(dir => {
            const angle = (this.directions.indexOf(dir) * 45);
            const label = document.createElement('div');
            label.style.position = 'absolute';
            label.style.left = '50%';
            label.style.top = '50%';
            label.style.transform = `translate(-50%, -50%) rotate(${angle}deg) translateY(-130px)`;
            label.style.fontSize = '11px';
            label.style.fontWeight = 'bold';
            label.style.color = '#FF9933';
            label.style.textAlign = 'center';
            label.style.width = '60px';
            label.innerHTML = `<div>${dir}</div><div style="font-size: 9px;">${this.vaastuLabels[dir]}</div>`;
            container.appendChild(label);
        });
    }

    handleOrientation(event) {
        // Use magnetic heading (beta) - most accurate for compass
        let heading = event.webkitCompassHeading || event.alpha || 0;
        if (event.webkitCompassHeading === undefined) {
            heading = 360 - heading; // Convert to standard compass heading
        }

        // Smooth the rotation and prevent spinning
        const compassRing = document.getElementById('compassRing');
        const normalizedHeading = heading % 360;
        compassRing.style.transform = `rotate(-${normalizedHeading}deg)`;

        // Update needle
        const needle = document.getElementById('needle');
        needle.style.transform = `rotate(-${normalizedHeading}deg) translateY(-50%)`;

        // Find current direction (22.5 degree tolerance)
        const dirIndex = Math.round(normalizedHeading / 45) % 8;
        const currentDir = this.directions[dirIndex] || 'N';
        
        document.getElementById('currentDirection').textContent = this.vaastuLabels[currentDir];
        document.getElementById('directionText').textContent = `${currentDir} दिशा`;
    }
}

// Inject compass CSS
const style = document.createElement('style');
style.textContent = `
    #compassRing {
        transition: transform 0.3s ease-out !important;
    }
    #needle {
        transition: transform 0.3s ease-out !important;
    }
    .needle-red {
        width: 3px;
        height: 110px;
        background: linear-gradient(to top, #dc2626, #ef4444);
        border-radius: 2px;
        margin: 0 auto;
        box-shadow: 0 0 8px rgba(220,38,38,0.6);
        transform-origin: bottom center;
    }
    .needle-bottom {
        width: 18px;
        height: 18px;
        background: #FF9933;
        border-radius: 50%;
        margin-top: -2px;
        box-shadow: 0 3px 10px rgba(255,153,51,0.4);
    }
`;
document.head.appendChild(style);

// Initialize when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => new VaastuCompass());
} else {
    new VaastuCompass();
}